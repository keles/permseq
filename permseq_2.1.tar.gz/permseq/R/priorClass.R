setClass("Prior",representation=representation(
                   dnaseName = "character",
                   dnaseAlign = "list",
                   dnaseKnots = "numeric",
                   dnaseThres = "numeric",
                   posLoc_bychr = "list",
                   dnaseHistone = "list",

                   histoneName = "character",
                   histoneNum = "numeric",
                   histoneAlign = "list",
                   histoneGrpL = "character",

                   chipName = "character",
                   chipNum = "numeric",
                   chipAlign = "list",
                   chipSAM = "character",
                   chipAllocate = "character",
                   chipUni = "character",
                   chipFormat = "character",

                   dataNum = "numeric",
                   fragL = "numeric",
                   bowtieInfo = "list",
                   csemDir = "character",
                   outfileLoc = "character",
                   prior = "character",
                   chrom.ref = "character"
 
  )
)

















